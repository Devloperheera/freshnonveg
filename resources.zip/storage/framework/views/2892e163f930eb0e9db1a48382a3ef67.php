<?php if(isset($faqs) && $faqs->isNotEmpty()): ?>
<section class="py-5" id="faq">
    <div class="container" style="max-width:800px">
        <h2 class="t text-center rv">अक्सर पूछे गए <u>सवाल</u> ❓</h2>
        <p class="sub text-center rv">FAQ</p>
        <div class="accordion rv" id="acc">
            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="accordion-item">
                    <h2 class="accordion-header">
                        <button class="accordion-button <?php echo e($loop->first ? '' : 'collapsed'); ?>"
                                type="button"
                                data-bs-toggle="collapse"
                                data-bs-target="#faq-<?php echo e($faq->id); ?>"
                                aria-expanded="<?php echo e($loop->first ? 'true' : 'false'); ?>"
                                aria-controls="faq-<?php echo e($faq->id); ?>">
                            <?php echo e($faq->question); ?>

                        </button>
                    </h2>
                    <div id="faq-<?php echo e($faq->id); ?>"
                         class="accordion-collapse collapse <?php echo e($loop->first ? 'show' : ''); ?>"
                         data-bs-parent="#acc">
                        <div class="accordion-body"><?php echo e($faq->answer); ?></div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Components/faq.blade.php ENDPATH**/ ?>