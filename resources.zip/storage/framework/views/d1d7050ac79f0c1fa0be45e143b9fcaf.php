<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <title><?php echo $__env->yieldContent('title', 'FreshNonVeg – Fresh Non Veg Delivered to Your Door'); ?></title>
    <meta name="title" content="<?php echo $__env->yieldContent('meta_title', 'FreshNonVeg | Fresh Non-Veg Delivery in Noida & NCR'); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'FreshNonVeg delivers fresh mutton, chicken, fish and seafood to your door. Only fresh, no frozen – direct from meat shop in Noida & NCR.'); ?>">
    <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', 'fresh non veg, mutton delivery, chicken delivery, Noida, Greater Noida, FreshNonVeg'); ?>">
    <meta name="robots" content="<?php echo $__env->yieldContent('meta_robots', 'index, follow'); ?>">
    <meta name="author" content="FreshNonVeg">
    <meta name="language" content="English">
    <meta name="revisit-after" content="7 days">

    
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $__env->yieldContent('og_url', url()->current()); ?>">
    <meta property="og:title" content="<?php echo $__env->yieldContent('og_title', 'FreshNonVeg | Fresh Non-Veg Delivery in Noida & NCR'); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('og_description', 'Fresh mutton, chicken, fish & seafood delivered fresh to your home in Noida & NCR.'); ?>">
    <meta property="og:image" content="<?php echo $__env->yieldContent('og_image', asset('website_assets/image/logo.png')); ?>">
    <meta property="og:site_name" content="FreshNonVeg">
    <meta property="og:locale" content="en_IN">

    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:url" content="<?php echo $__env->yieldContent('twitter_url', url()->current()); ?>">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('twitter_title', 'FreshNonVeg | Fresh Non-Veg Delivery in Noida & NCR'); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('twitter_description', 'Fresh mutton, chicken, fish & seafood delivered to your door in Noida & NCR.'); ?>">
    <meta name="twitter:image" content="<?php echo $__env->yieldContent('twitter_image', asset('website_assets/image/logo.png')); ?>">

    
    <meta name="geo.region" content="IN-DL">
    <meta name="geo.placename" content="New Delhi">
    <meta name="geo.position" content="28.6139;77.2090">
    <meta name="ICBM" content="28.6139, 77.2090">

    
    <link rel="canonical" href="<?php echo $__env->yieldContent('canonical_url', url()->current()); ?>">

    
    <link rel="icon" href="<?php echo $__env->yieldContent('favicon', asset('website_assets/image/favicon.png')); ?>" type="image/png">
    <link rel="shortcut icon" href="<?php echo $__env->yieldContent('favicon', asset('website_assets/image/favicon.png')); ?>" type="image/png">

    
    <?php echo $__env->make('Website.Layout.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('custom_css'); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->make('Website.Layout.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('Website.Layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('Website.Layout.mobile-bottom-nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('Website.Layout.js', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->yieldContent('custom_js'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Layout/master.blade.php ENDPATH**/ ?>