<?php if(isset($testimonials) && $testimonials->isNotEmpty()): ?>
<section class="py-5" style="background:rgba(236,72,153,.1)">
    <div class="container text-center">
        <h2 class="t rv">Customers <u>क्या कहते हैं</u> 💬</h2>
        <p class="sub rv">असली लोग, असली taste</p>
        <div class="owl-carousel owl-theme testimonial-carousel rv">
            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item px-1">
                    <div class="fcard h-100 text-start">
                        <div class="stars" aria-label="<?php echo e($testimonial->star_rating); ?> out of 5"><?php echo $testimonial->starsHtml(); ?></div>
                        <p class="text-dark mb-3">"<?php echo e($testimonial->short_description); ?>"</p>
                        <h4 class="mb-0">– <?php echo e($testimonial->name); ?></h4>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Components/testimonials.blade.php ENDPATH**/ ?>