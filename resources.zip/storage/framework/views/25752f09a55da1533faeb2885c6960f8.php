<?php
    $image = $product->images->first();
    $fromPrice = $product->weights->min('price');
    $tagLabel = $product->tags->first()?->name ?? ($product->is_featured ? 'Featured' : null);
    $excerpt = $product->meta_description ?: strip_tags((string) $product->description);
    $excerpt = \Illuminate\Support\Str::limit($excerpt, 72);
    $bgColors = ['#fde2e2', '#fff3c4', '#dbeafe', '#d6f5e3', '#fbd5e8', '#ffedd5'];
    $cardIndex = isset($loop) ? $loop->index : (int) $product->id;
    $bg = $bgColors[$cardIndex % count($bgColors)] ?? '#fde2e2';
?>
<div class="col-6 col-lg-3 rv product-card-col" id="product-<?php echo e($product->id); ?>">
    <div class="fcard h-100">
        <?php if($tagLabel): ?>
            <span class="tag"><?php echo e($tagLabel); ?></span>
        <?php endif; ?>
        <div class="pimg pimg-photo" style="background:<?php echo e($bg); ?>">
            <?php if($image): ?>
                <img src="<?php echo e($image->url()); ?>" alt="<?php echo e($product->name); ?>" loading="lazy">
            <?php else: ?>
                <span class="pimg-fallback">🥩</span>
            <?php endif; ?>
        </div>
        <h4><?php echo e($product->name); ?></h4>
        <?php if($product->category): ?>
            <p class="small text-muted mb-1"><?php echo e($product->category->name); ?></p>
        <?php endif; ?>
        <p><?php echo e($excerpt ?: 'Fresh quality, hygienically packed.'); ?></p>
        <div class="d-flex justify-content-between align-items-center mt-3">
            <span class="price">
                <?php if($fromPrice !== null): ?>
                    ₹<?php echo e(number_format((float) $fromPrice, 0)); ?>

                <?php else: ?>
                    —
                <?php endif; ?>
            </span>
            <a class="btn btn-fun btn-red btn-sm px-3" href="<?php echo e(route('products.show', $product)); ?>">View</a>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/partials/product-card.blade.php ENDPATH**/ ?>