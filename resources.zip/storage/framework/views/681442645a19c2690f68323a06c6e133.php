<?php if($siteStats->isNotEmpty()): ?>
<section class="stats py-5"><div class="container"><div class="row g-4 text-center">
    <?php $__currentLoopData = $siteStats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-6 col-md-3">
        <h3 data-n="<?php echo e($stat->value); ?>">0</h3>
        <p class="m-0 fw-semibold"><?php echo e($stat->label); ?></p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div></div></section>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Components/statics.blade.php ENDPATH**/ ?>