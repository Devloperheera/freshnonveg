<?php
    $guestLoginUrl = $guestLoginUrl ?? route('login');
    $wishlistUrl = auth()->check() ? route('wishlist') : $guestLoginUrl;
    $cartUrl = auth()->check() ? route('cart') : $guestLoginUrl;
    $accountUrl = auth()->check() ? route('dashboard') : $guestLoginUrl;
    $isHome = request()->routeIs('home');
    $isSearch = request()->routeIs('shop.index');
    $isWishlist = request()->routeIs('wishlist');
    $isCart = request()->routeIs('cart');
    $isAccount = request()->routeIs('profile', 'login', 'register');
?>
<nav class="mobile-bottom-nav d-md-none" aria-label="Mobile navigation">
    <a href="<?php echo e(route('home')); ?>" class="mobile-bottom-nav__item <?php echo e($isHome ? 'active' : ''); ?>">
        <i class="bi bi-house" aria-hidden="true"></i>
        <span>Home</span>
    </a>
    <button type="button" class="mobile-bottom-nav__item <?php echo e($isSearch ? 'active' : ''); ?>" id="mobileBottomSearch" aria-label="Open search">
        <i class="bi bi-search" aria-hidden="true"></i>
        <span>Search</span>
    </button>
    <a href="<?php echo e($wishlistUrl); ?>" class="mobile-bottom-nav__item <?php echo e($isWishlist ? 'active' : ''); ?>">
        <i class="bi bi-heart" aria-hidden="true"></i>
        <span>Wishlist</span>
    </a>
    <a href="<?php echo e($cartUrl); ?>" class="mobile-bottom-nav__item <?php echo e($isCart ? 'active' : ''); ?>">
        <i class="bi bi-bag" aria-hidden="true"></i>
        <span>Cart</span>
    </a>
    <a href="<?php echo e($accountUrl); ?>" class="mobile-bottom-nav__item <?php echo e($isAccount ? 'active' : ''); ?>">
        <i class="bi bi-person" aria-hidden="true"></i>
        <span>Account</span>
    </a>
</nav>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    var btn = document.getElementById('mobileBottomSearch');
    if (!btn) return;
    btn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        setTimeout(function () {
            var toggle = document.getElementById('headerSearchToggle');
            if (toggle) toggle.click();
        }, 280);
    });
})();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Layout/mobile-bottom-nav.blade.php ENDPATH**/ ?>