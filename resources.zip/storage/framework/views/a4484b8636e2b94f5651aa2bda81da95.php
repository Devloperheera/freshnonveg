<section class="py-5" id="shop">
    <div class="container text-center">
        <h2 class="t rv">Featured <u>Products</u></h2>
        <p class="sub rv">सबसे ज्यादा बिकने वाले! 🔥</p>
        <div class="row g-2 g-md-4 text-start">
            <?php $__empty_1 = true; $__currentLoopData = $products ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php echo $__env->make('Website.partials.product-card', ['product' => $product], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 rv">
                    <div class="fcard text-center py-4">
                        <p class="mb-0 text-muted">Abhi koi product available nahi hai.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php if(!empty($hasMoreProducts)): ?>
            <a class="btn btn-fun btn-red btn-lg mt-4 px-4 rv"
               href="<?php echo e(route('shop.index', request()->only(['category', 'tag', 'q', 'product']))); ?>">
                VIEW ALL PRODUCTS →
            </a>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Components/products.blade.php ENDPATH**/ ?>