<?php $__env->startSection('title', 'Login – FreshNonVeg'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Website.Auth.partials.styles', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php
    $mode = old('login_mode', session('login_mode', 'password'));
    $otpSent = session('otp_sent', false);
?>
<div class="auth-wrap auth-wrap--compact">
    <div class="auth-card auth-card--compact">
        <h1>फिर से स्वागत है 👋</h1>
        <p class="sub"><strong>Login</strong> karein — ईमेल या फोन से, <strong>Password</strong> ya <strong>OTP</strong> — dono chalega!</p>

        <div class="auth-tabs mb-compact">
            <button type="button" class="auth-tab <?php echo e($mode === 'password' ? 'active' : ''); ?>" data-mode="password">Password</button>
            <button type="button" class="auth-tab <?php echo e($mode === 'otp' ? 'active' : ''); ?>" data-mode="otp">OTP</button>
        </div>

        <div class="mb-compact">
            <label class="form-label">ईमेल / मोबाइल (Email / Phone)</label>
            <input type="text" id="loginIdentifier" class="form-control <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('login')); ?>" placeholder="email@example.com ya 98XXXXXXXX" required autofocus>
            <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div id="panelPassword" class="<?php echo e($mode === 'otp' ? 'd-none' : ''); ?>">
            <form method="POST" action="<?php echo e(route('login.post')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="login" id="loginPasswordHidden" value="<?php echo e(old('login')); ?>">
                <div class="mb-compact">
                    <div class="d-flex justify-content-between align-items-center">
                        <label class="form-label mb-0">पासवर्ड (Password)</label>
                        <a href="<?php echo e(route('password.forgot')); ?>" class="small fw-bold">पासवर्ड भूल गए?</a>
                    </div>
                    <div class="pass-wrap mt-1">
                        <input type="password" name="password" id="passwordInput" class="form-control" placeholder="Apna password daalein" required>
                        <button type="button" class="pass-toggle" data-toggle-pass="passwordInput" data-toggle-icon="eyeIcon" aria-label="Show password"><i class="bi bi-eye" id="eyeIcon"></i></button>
                    </div>
                </div>
                <button type="submit" class="btn btn-brand mb-2">पासवर्ड से Login</button>
            </form>
        </div>

        <div id="panelOtp" class="<?php echo e($mode === 'password' ? 'd-none' : ''); ?>">
            <?php if(! $otpSent): ?>
                <p class="small text-muted mb-2">नंबर par SMS, ईमेल par mail — OTP jaldi aa jayega 📩</p>
                <form method="POST" action="<?php echo e(route('login.otp.send')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="login" id="loginOtpSendHidden" value="<?php echo e(old('login')); ?>">
                    <button type="submit" class="btn btn-brand mb-2">OTP भेजें (Send OTP)</button>
                </form>
            <?php else: ?>
                <form method="POST" action="<?php echo e(route('login.otp.verify')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="login" id="loginOtpVerifyHidden" value="<?php echo e(old('login')); ?>">
                    <label class="form-label">6 अंकों का OTP डालें</label>
                    <input type="text" name="otp" maxlength="6" pattern="[0-9]{6}" class="form-control mb-compact text-center <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="••••••" required autofocus>
                    <?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button type="submit" class="btn btn-brand mb-2">Verify करें & Login ✅</button>
                </form>
                <form method="POST" action="<?php echo e(route('login.otp.send')); ?>" class="text-center">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="login" id="loginOtpResendHidden" value="<?php echo e(old('login')); ?>">
                    <button type="submit" class="btn btn-link p-0 fw-bold small">OTP दोबारा भेजें</button>
                </form>
            <?php endif; ?>
        </div>

        <a href="<?php echo e($guestGoogleUrl ?? route('auth.google')); ?>" class="btn btn-google d-flex align-items-center justify-content-center gap-2">
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" width="18" alt=""> Google से Login
        </a>

        <div class="auth-links">
            नए user ho? <a href="<?php echo e($guestRegisterUrl ?? route('register')); ?>">रजिस्टर / Sign Up karein</a>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const identifier = document.getElementById('loginIdentifier');
    const syncLogin = () => {
        const v = identifier.value.trim();
        ['loginPasswordHidden','loginOtpSendHidden','loginOtpVerifyHidden','loginOtpResendHidden'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.value = v;
        });
    };
    identifier.addEventListener('input', syncLogin);
    syncLogin();

    document.querySelectorAll('.auth-tab').forEach(btn => {
        btn.addEventListener('click', () => {
            const mode = btn.dataset.mode;
            document.querySelectorAll('.auth-tab').forEach(b => b.classList.toggle('active', b.dataset.mode === mode));
            document.getElementById('panelPassword').classList.toggle('d-none', mode !== 'password');
            document.getElementById('panelOtp').classList.toggle('d-none', mode !== 'otp');
        });
    });
});
</script>
<?php echo $__env->make('Website.Auth.partials.pass-toggle-script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Website.Layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Auth/login.blade.php ENDPATH**/ ?>