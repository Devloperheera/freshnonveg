<?php
    $catBackgrounds = ['#fde2e2', '#fff3c4', '#d6f5e3', '#dbeafe', '#fbd5e8', '#e9d5ff', '#ffedd5', '#ecfccb'];
?>
<section class="py-5" style="background:rgba(255,217,61,.18)">
    <div class="container text-center">
        <h2 class="t rv">Shop by <u>Category</u></h2>
        <p class="sub rv">केटेगरी चुनें 👇</p>
        <div class="row g-2 g-md-4 justify-content-center home-categories-row">
            <?php $__empty_1 = true; $__currentLoopData = $categories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-4 col-md-4 col-lg-3 rv">
                    <a class="cat cat-with-img"
                       style="background:<?php echo e($catBackgrounds[$loop->index % count($catBackgrounds)]); ?>"
                       href="<?php echo e(route('shop.index', ['category' => $category->id])); ?>">
                        <img src="<?php echo e($category->imageUrl()); ?>" alt="<?php echo e($category->name); ?>" width="80" height="80" loading="lazy">
                        <span class="cat-name"><?php echo e($category->name); ?></span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 rv">
                    <p class="text-muted mb-0">Abhi koi category available nahi hai.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Components/category.blade.php ENDPATH**/ ?>