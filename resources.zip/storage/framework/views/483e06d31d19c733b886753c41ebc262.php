<?php if($advantageItems->isNotEmpty()): ?>
<section class="py-5 home-advantages-section"><div class="container text-center">
    <?php if($advantagesSection): ?>
        <h2 class="t rv"><?php echo \App\Support\SafeHtml::display($advantagesSection->title); ?></h2>
        <?php if($advantagesSection->subtitle): ?>
            <p class="sub rv"><?php echo e($advantagesSection->subtitle); ?></p>
        <?php endif; ?>
    <?php else: ?>
        <h2 class="t rv">Fresh खाने के <u>फायदे!</u></h2>
        <p class="sub rv">ताज़ा गोश्त क्यों है बेहतर? 🤔</p>
    <?php endif; ?>
    <div class="owl-carousel owl-theme advantages-carousel rv">
      <?php $__currentLoopData = $advantageItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="item home-advantage-col">
        <div class="fcard h-100">
          <?php if($item->icon): ?>
            <div class="ic"><?php echo e($item->icon); ?></div>
          <?php endif; ?>
          <h4><?php echo e($item->title); ?></h4>
          <?php if($item->description): ?>
            <p><?php echo e($item->description); ?></p>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div></section>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Components/advantages.blade.php ENDPATH**/ ?>