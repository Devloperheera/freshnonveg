<?php if($orderSteps->isNotEmpty()): ?>
<section class="py-5" style="background:rgba(34,193,195,.12)"><div class="container text-center">
    <?php if($orderWaySection): ?>
        <h2 class="t rv"><?php echo \App\Support\SafeHtml::display($orderWaySection->title); ?></h2>
        <?php if($orderWaySection->subtitle): ?>
            <p class="sub rv"><?php echo e($orderWaySection->subtitle); ?></p>
        <?php endif; ?>
    <?php else: ?>
        <h2 class="t rv">Order करना है <u>आसान</u></h2>
        <p class="sub rv">बस 4 steps में ताज़ा गोश्त आपके दरवाज़े पर 🚪</p>
    <?php endif; ?>
    <div class="row g-4">
      <?php $__currentLoopData = $orderSteps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-6 col-md-3 rv">
        <div class="num"><?php echo e($index + 1); ?></div>
        <h4><?php echo e($step->title); ?></h4>
        <?php if($step->description): ?>
            <p class="sub m-0"><?php echo e($step->description); ?></p>
        <?php endif; ?>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div></section>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Components/orderway.blade.php ENDPATH**/ ?>