<!-- HERO: Owl Carousel — admin banners (image only) -->
<section class="hero">
    <?php if(isset($banners) && $banners->isNotEmpty()): ?>
        <div class="owl-carousel owl-theme" id="hero">
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="hero-slide">
                    <img src="<?php echo e($banner->imageUrl()); ?>" alt="<?php echo e($banner->name); ?>" loading="<?php echo e($loop->first ? 'eager' : 'lazy'); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</section>
<?php /**PATH D:\xampp\htdocs\fresh-non-veg\resources\views/Website/Components/herosection.blade.php ENDPATH**/ ?>